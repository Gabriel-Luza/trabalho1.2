a = int(input("Insira a quantidade de eleitores: "))

cand1 = 0
cand2 = 0
cand3 = 0

for votos in range(a):

    b = input("Vote em: |a| |b| |c| = ")

    if b == "a":
        cand1 = cand1 + 1

    elif b == "b":
        cand2 = cand2 + 1

    elif b == "c":
        cand3 = cand3 + 1

print("O candidato A ficou com {}, votos.".format(cand1))
print("O candidato B ficou com {}, votos.".format(cand2))
print("O candidato C ficou com {}, votos.".format(cand3))
