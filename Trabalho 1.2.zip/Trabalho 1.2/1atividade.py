print("Digite 0 para começar!")

condicao = True

soma = 0

numero = []

while condicao:
    num = int(input("Informe um número para fazer seu fatorial: "))

    if (num != 0) and (num < 16):

        resultado=1
        count=1
        while count <= num:
                resultado *= count
                count += 1
        print("O fatorial é: {}".format(resultado))