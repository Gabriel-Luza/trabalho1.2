num =  int(input('Digite um número: '))

result = 0

for c in range(1, num + 1):

    if num % c == 0:
        print(' \033[34m' , end='')
        result += 1

    else:
        print(' \033[31m' , end='')

    print(f'{c}', end='')

print(f'\n\33[mO número {num} foi divisivel {result} vezes!')

if result == 2:
    print('E por isso é um número Primo!')

else:
    print('E por isso não é um número Primo!')