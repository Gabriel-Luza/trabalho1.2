quant = int(input("Digite a quantidade de CDs: "))

a = 0
valortotal = 0

for x in range(quant):

	valor = eval(input("Digite o valor do CD: "))
	valortotal = valortotal + valor
	valormedio = valortotal / quant
	a = a + 1

print("O valor total gasto: R${}".format(valortotal))
print("O valor médio gasto por cada CD foi de: R${}".format(valormedio))