print("Quando achar que a quantidade de números é suficiente digite 0!")

condicao = True

soma=0
numero=[]

while condicao:
    num=int(input('Informe um número: '))

    if num != 0:
        soma += num
        numero.append(num)
    else:
        print("Número inseridos!")
        break

print('A soma total é de: {}'.format(soma))
print('Menor Valor inserido: ', min(numero))
print('Maior Valor inserido: ', max(numero))