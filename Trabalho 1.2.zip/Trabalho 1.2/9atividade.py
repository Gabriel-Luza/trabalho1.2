from pip._vendor.distlib.compat import raw_input

pessoa = int(raw_input("Informe a quantidade de Pessoas: "))
maior = None
menor = None
somaidade = 0

for i in range(pessoa):

    idade = int(raw_input("Informe a idade: "))
    somaidade += idade

    if maior == None and menor == None:
        maior, menor = idade, idade

    if idade > maior:
        maior = idade

    if idade < menor:
        menor = idade

media = somaidade / pessoa

if 0 < media <= 25:
    turma = "Jovens"

elif 26 <= media <= 60:
    turma = "Adultas"

else:
    turma = "Idosas"

print('A maior parte das pessoas são {}'.format(turma))
print('A média de idade é {}'.format(media))
